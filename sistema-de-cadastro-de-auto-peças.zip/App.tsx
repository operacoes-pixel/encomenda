import React, { useState, useCallback, useEffect } from 'react';
import Header from './components/Header';
import ProductForm from './components/ProductForm';
import Notification from './components/Notification';
import ProductTable from './components/ProductTable';
import type { Product } from './types';
import { exportToExcel } from './services/excelService';

// --- INÍCIO DA CONFIGURAÇÃO DO FIREBASE ---
// IMPORTANTE: Substitua os valores abaixo pelos do seu projeto Firebase.
// Você encontra isso nas Configurações do Projeto > Geral > Seus apps > Configuração do SDK.
 const firebaseConfig = {
    apiKey: "AIzaSyCC9J1zTZJJUmZ-B66zmJQTjyEQel9ZpLk",
    authDomain: "encomenda-3c81d.firebaseapp.com",
    projectId: "encomenda-3c81d",
    storageBucket: "encomenda-3c81d.firebasestorage.app",
    messagingSenderId: "282318835747",
    appId: "1:282318835747:web:e2d4527d19809c289e6196"
  };
// --- FIM DA CONFIGURAÇÃO DO FIREBASE ---

const GITHUB_URL = 'https://github.com/google/gemini-codelab/tree/main/demos/parts-inventory-manager';
const INITIAL_ROWS = 10;

const createInitialProducts = (): Product[] => {
    return Array.from({ length: INITIAL_ROWS }, () => ({
        internalCode: '',
        date: '',
        reference: '',
        description: '',
        quantity: '',
        requester: '',
        brand: '',
    }));
};

type NotificationState = {
    message: string;
    type: 'success' | 'error';
} | null;

const App: React.FC = () => {
    const [newProducts, setNewProducts] = useState<Product[]>(createInitialProducts());
    const [savedProducts, setSavedProducts] = useState<Product[]>([]);
    const [filteredProducts, setFilteredProducts] = useState<Product[]>([]);
    const [isLoading, setIsLoading] = useState(false);
    const [isFetching, setIsFetching] = useState(true);
    const [fetchError, setFetchError] = useState<string | null>(null);
    const [notification, setNotification] = useState<NotificationState>(null);
    const [db, setDb] = useState<any>(null);
    const [startDate, setStartDate] = useState('');
    const [endDate, setEndDate] = useState('');

    useEffect(() => {
        // Inicializa o Firebase e o Firestore
        // @ts-ignore
        if (firebase.apps.length === 0) {
             // @ts-ignore
            firebase.initializeApp(firebaseConfig);
        }
         // @ts-ignore
        const firestore = firebase.firestore();
        setDb(firestore);

        // Configura o listener em tempo real para buscar produtos
        const unsubscribe = firestore.collection('products').orderBy('date', 'desc').onSnapshot(
            (snapshot: any) => {
                const productsData: Product[] = snapshot.docs.map((doc: any) => ({
                    id: doc.id,
                    ...doc.data(),
                }));
                setSavedProducts(productsData);
                // A busca inicial não acontece mais aqui, apenas carrega os dados
            },
            (error: any) => {
                console.error("Erro ao buscar produtos do Firestore: ", error);
                setFetchError('Falha ao carregar produtos. Tente recarregar a página.');
                setIsFetching(false);
            }
        );

        // Limpa a inscrição ao desmontar o componente
        return () => unsubscribe();
    }, []);


    const handleProductChange = useCallback((index: number, field: keyof Product, value: string) => {
        setNewProducts(currentProducts => {
            const updatedProducts = [...currentProducts];
            updatedProducts[index] = { ...updatedProducts[index], [field]: value };
            return updatedProducts;
        });
    }, []);

    const handleSave = useCallback(async () => {
        if (!db) {
            setNotification({ message: 'Erro: Banco de dados não inicializado.', type: 'error' });
            return;
        }

        const productsToSave = newProducts.filter(p =>
            Object.values(p).some(val => val !== '')
        );

        if (productsToSave.length === 0) {
            setNotification({ message: 'Nenhum produto para salvar. Preencha o formulário.', type: 'error' });
            return;
        }

        setIsLoading(true);
        setNotification(null);

        try {
            const batch = db.batch();
            
            productsToSave.forEach(product => {
                const docRef = db.collection('products').doc();
                batch.set(docRef, product);
            });

            await batch.commit();

            setNotification({ message: 'Produtos salvos com sucesso!', type: 'success' });
            setNewProducts(createInitialProducts());

        } catch (error) {
            console.error("Erro ao salvar no Firestore: ", error);
            const errorMessage = error instanceof Error ? error.message : 'Ocorreu um erro desconhecido.';
            setNotification({ message: `Falha ao salvar produtos: ${errorMessage}`, type: 'error' });
        } finally {
            setIsLoading(false);
        }
    }, [newProducts, db]);

    const handleClearForm = useCallback(() => {
        if (window.confirm('Tem certeza que deseja limpar todos os campos do formulário?')) {
            setNewProducts(createInitialProducts());
        }
    }, []);
    
    const handleSearch = useCallback(() => {
        setIsFetching(true);
        setFilteredProducts([]); // Limpa resultados anteriores

        if (!startDate && !endDate) {
            setFilteredProducts(savedProducts);
            setNotification({ message: `Exibindo todos os ${savedProducts.length} produtos.`, type: 'success' });
            setIsFetching(false);
            return;
        }

        const filtered = savedProducts.filter(product => {
            if (!product.date || !/^\d{4}-\d{2}-\d{2}$/.test(product.date)) {
                return false;
            }
            const productDate = new Date(product.date + 'T00:00:00');
            
            const start = startDate ? new Date(startDate + 'T00:00:00') : null;
            const end = endDate ? new Date(endDate + 'T23:59:59') : null;
            
            if (start && end) {
                return productDate >= start && productDate <= end;
            }
            if (start) {
                return productDate >= start;
            }
            if (end) {
                return productDate <= end;
            }
            return true;
        });
        
        if (filtered.length === 0) {
            setNotification({ message: 'Nenhum produto encontrado no período selecionado.', type: 'error' });
        } else {
            setNotification({ message: `${filtered.length} produto(s) encontrado(s).`, type: 'success' });
        }
        setFilteredProducts(filtered);
        setIsFetching(false);

    }, [savedProducts, startDate, endDate]);

    const handleClearFilter = useCallback(() => {
        setStartDate('');
        setEndDate('');
        setFilteredProducts([]); // Limpa a tabela
        setNotification({ message: 'Filtro limpo. Realize uma nova busca para ver os produtos.', type: 'success' });
    }, []);


    const handleExport = useCallback(() => {
        if (filteredProducts.length === 0) {
            setNotification({ message: 'Não há produtos na lista para exportar. Realize uma busca primeiro.', type: 'error' });
            return;
        }

        try {
            exportToExcel(filteredProducts, 'relatorio_produtos');
            setNotification({ message: 'Exportação para Excel gerada com sucesso!', type: 'success' });
        } catch (error) {
            console.error("Erro ao exportar para Excel: ", error);
            setNotification({ message: 'Ocorreu um erro ao gerar o arquivo Excel.', type: 'error' });
        }
    }, [filteredProducts]);
    
    const SaveIcon = () => (
        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M8 7H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-3m-1 4l-3 3m0 0l-3-3m3 3V4" />
        </svg>
    );

    const LoadingSpinner = () => (
        <svg className="animate-spin h-5 w-5 mr-2 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
        </svg>
    );

    const TrashIcon = () => (
        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
        </svg>
    );

    const GitHubIcon = () => (
        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="currentColor" viewBox="0 0 16 16">
            <path d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.012 8.012 0 0 0 16 8c0-4.42-3.58-8-8-8z"/>
        </svg>
    );

    const ExcelIcon = () => (
        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
            <path d="M2 3a1 1 0 011-1h14a1 1 0 011 1v14a1 1 0 01-1-1H3a1 1 0 01-1-1V3z" />
            <path fillRule="evenodd" d="M13.435 5.586a.5.5 0 01.353.147l1.414 1.414a.5.5 0 010 .707l-4.242 4.243a.5.5 0 01-.354.146H8.5a.5.5 0 01-.5-.5v-2.121a.5.5 0 01.146-.354l4.243-4.242a.5.5 0 01.54-.03zM12 7.5L9.5 10H10v.5L12.5 8H12v-.5zM7 13h6v-2h-1v1.5H8V11H7v2z" clipRule="evenodd" fill="#FFFFFF"/>
        </svg>
    );

    const SearchIcon = () => (
        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
        </svg>
    );

    const ClearIcon = () => (
         <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
    );


    return (
        <div className="flex flex-col min-h-screen bg-zinc-900">
            <Header />
            {notification && (
                <Notification
                    message={notification.message}
                    type={notification.type}
                    onClose={() => setNotification(null)}
                />
            )}
            <main className="flex-grow container mx-auto p-4 md:p-6 lg:p-8 space-y-8">
                <div>
                  <h2 className="text-lg font-semibold text-orange-500 mb-3">Adicionar Novos Produtos</h2>
                  <ProductForm products={newProducts} onProductChange={handleProductChange} />
                </div>
                <div>
                  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-3 gap-4">
                      <h2 className="text-lg font-semibold text-orange-500 whitespace-nowrap">Produtos Cadastrados</h2>
                      <div className="flex items-center gap-2 flex-wrap w-full sm:w-auto sm:justify-end">
                          <label htmlFor="startDate" className="text-sm text-gray-300">De:</label>
                          <input
                              type="date"
                              id="startDate"
                              value={startDate}
                              onChange={(e) => setStartDate(e.target.value)}
                              className="bg-zinc-700 border border-zinc-600 text-white text-sm rounded-lg focus:ring-orange-500 focus:border-orange-500 block p-2"
                          />
                           <label htmlFor="endDate" className="text-sm text-gray-300">Até:</label>
                          <input
                              type="date"
                              id="endDate"
                              value={endDate}
                              onChange={(e) => setEndDate(e.target.value)}
                              className="bg-zinc-700 border border-zinc-600 text-white text-sm rounded-lg focus:ring-orange-500 focus:border-orange-500 block p-2"
                          />
                          <button
                              onClick={handleSearch}
                              className="flex items-center justify-center px-4 py-2.5 text-sm font-medium text-white bg-orange-600 rounded-lg hover:bg-orange-700 focus:ring-4 focus:outline-none focus:ring-orange-500 transition-colors duration-200"
                              title="Buscar produtos no período selecionado"
                          >
                              <SearchIcon />
                              Buscar
                          </button>
                          <button
                              onClick={handleClearFilter}
                              className="flex items-center justify-center px-4 py-2.5 text-sm font-medium text-white bg-yellow-600 rounded-lg hover:bg-yellow-700 focus:ring-4 focus:outline-none focus:ring-yellow-800 transition-colors duration-200"
                              title="Limpar filtro de data"
                          >
                              <ClearIcon />
                              Limpar
                          </button>
                          <button
                              onClick={handleExport}
                              className="flex items-center justify-center px-4 py-2.5 text-sm font-medium text-white bg-green-600 rounded-lg hover:bg-green-700 focus:ring-4 focus:outline-none focus:ring-green-800 transition-colors duration-200"
                              title="Exportar dados filtrados para Excel"
                          >
                              <ExcelIcon />
                              Exportar
                          </button>
                      </div>
                  </div>
                  <ProductTable products={filteredProducts} isLoading={false} error={fetchError} />
                </div>
            </main>
            <footer className="bg-zinc-800/50 backdrop-blur-sm p-4 sticky bottom-0 border-t border-zinc-700 shadow-t-xl">
                <div className="container mx-auto flex items-center justify-center sm:justify-end space-x-2 sm:space-x-4">
                     <button
                        onClick={() => window.open(GITHUB_URL, '_blank')}
                        className="flex items-center justify-center px-4 py-2 text-sm font-medium text-orange-400 bg-zinc-700 rounded-lg hover:bg-zinc-600 focus:ring-4 focus:outline-none focus:ring-zinc-800 transition-all duration-300 transform hover:scale-105"
                        title="Ver no GitHub"
                        aria-label="Ver código fonte no GitHub"
                    >
                        <GitHubIcon />
                        Ver no GitHub
                    </button>
                    <button
                        onClick={handleClearForm}
                        disabled={isLoading}
                        className="flex items-center justify-center px-4 py-2 text-sm font-medium text-white bg-red-600 rounded-lg hover:bg-red-700 focus:ring-4 focus:outline-none focus:ring-red-800 transition-all duration-300 transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                        <TrashIcon />
                        Limpar Formulário
                    </button>
                    <button
                        onClick={handleSave}
                        disabled={isLoading || !db}
                        className="flex items-center justify-center px-4 py-2 text-sm font-medium text-white bg-orange-600 rounded-lg hover:bg-orange-700 focus:ring-4 focus:outline-none focus:ring-orange-500 transition-all duration-300 transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                        {isLoading ? <LoadingSpinner /> : <SaveIcon />}
                        {isLoading ? 'Salvando...' : 'Salvar no Banco de Dados'}
                    </button>
                </div>
            </footer>
        </div>
    );
};

export default App;