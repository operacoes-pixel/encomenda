import React from 'react';
import type { Product } from '../types';

interface ProductTableProps {
    products: Product[];
    isLoading: boolean;
    error: string | null;
}

const ProductTable: React.FC<ProductTableProps> = ({ products, isLoading, error }) => {
    const headers = ['Código Interno', 'Data', 'Referência', 'Descrição', 'Quantidade', 'Solicitante', 'Marca'];

    const renderTableContent = () => {
        if (isLoading) {
            return (
                <tr>
                    <td colSpan={headers.length} className="text-center py-4 text-orange-400">
                        Carregando produtos...
                    </td>
                </tr>
            );
        }

        if (error) {
            return (
                <tr>
                    <td colSpan={headers.length} className="text-center py-4 text-red-400">
                        {error}
                    </td>
                </tr>
            );
        }

        if (products.length === 0) {
            return (
                <tr>
                    <td colSpan={headers.length} className="text-center py-4 text-orange-400">
                        Nenhum produto para exibir. Realize uma busca para ver os resultados.
                    </td>
                </tr>
            );
        }

        return products.map((product) => (
            <tr key={product.id} className="border-b border-zinc-700 hover:bg-zinc-700/50 transition-colors duration-200 text-gray-200">
                <td className="px-4 py-3 whitespace-nowrap">{product.internalCode}</td>
                <td className="px-4 py-3 whitespace-nowrap">{product.date}</td>
                <td className="px-4 py-3 whitespace-nowrap">{product.reference}</td>
                <td className="px-4 py-3 min-w-[250px]">{product.description}</td>
                <td className="px-4 py-3 text-center">{product.quantity}</td>
                <td className="px-4 py-3 whitespace-nowrap">{product.requester}</td>
                <td className="px-4 py-3 whitespace-nowrap">{product.brand}</td>
            </tr>
        ));
    };

    return (
        <div className="w-full overflow-x-auto rounded-lg shadow-xl bg-zinc-800">
            <table className="w-full text-sm text-left text-gray-200">
                <thead className="text-xs text-orange-400 uppercase bg-zinc-700">
                    <tr>
                        {headers.map(header => (
                            <th key={header} scope="col" className="px-4 py-3 whitespace-nowrap">
                                {header}
                            </th>
                        ))}
                    </tr>
                </thead>
                <tbody>
                    {renderTableContent()}
                </tbody>
            </table>
        </div>
    );
};

export default ProductTable;