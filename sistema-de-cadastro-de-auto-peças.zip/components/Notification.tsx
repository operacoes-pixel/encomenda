import React, { useEffect } from 'react';

interface NotificationProps {
    message: string;
    type: 'success' | 'error';
    onClose: () => void;
}

const Notification: React.FC<NotificationProps> = ({ message, type, onClose }) => {
    useEffect(() => {
        const timer = setTimeout(() => {
            onClose();
        }, 5000); // Fecha a notificação automaticamente após 5 segundos

        return () => clearTimeout(timer);
    }, [onClose]);

    const baseClasses = 'p-4 rounded-md text-white fixed top-20 left-1/2 -translate-x-1/2 shadow-lg z-50 flex items-center';
    const typeClasses = {
        success: 'bg-green-600',
        error: 'bg-red-600',
    };

    return (
        <div role="alert" className={`${baseClasses} ${typeClasses[type]}`}>
            <span className="flex-grow">{message}</span>
            <button onClick={onClose} className="ml-4 font-bold text-xl hover:text-gray-300">&times;</button>
        </div>
    );
};

export default Notification;
