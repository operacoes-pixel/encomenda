import React from 'react';
import type { Product } from '../types';

interface ProductFormProps {
    products: Product[];
    onProductChange: (index: number, field: keyof Product, value: string) => void;
}

const ProductForm: React.FC<ProductFormProps> = ({ products, onProductChange }) => {
    const headers = ['#', 'Código Interno', 'Data', 'Referência', 'Descrição', 'Quantidade', 'Solicitante', 'Marca'];

    return (
        <div className="w-full overflow-x-auto rounded-lg shadow-xl bg-zinc-800">
            <table className="w-full text-sm text-left text-gray-200">
                <thead className="text-xs text-orange-400 uppercase bg-zinc-700">
                    <tr>
                        {headers.map(header => (
                            <th key={header} scope="col" className="px-4 py-3 whitespace-nowrap">
                                {header}
                            </th>
                        ))}
                    </tr>
                </thead>
                <tbody>
                    {products.map((product, index) => (
                        <tr key={index} className="border-b border-zinc-700 hover:bg-zinc-700/50 transition-colors duration-200">
                            <td className="px-4 py-3 font-medium text-gray-300">{index + 1}</td>
                            <td className="px-2 py-2">
                                <input
                                    type="text"
                                    value={product.internalCode}
                                    onChange={(e) => onProductChange(index, 'internalCode', e.target.value)}
                                    className="bg-zinc-900 border border-zinc-700 text-white text-sm rounded-lg focus:ring-orange-500 focus:border-orange-500 block w-full p-2.5 placeholder-gray-500"
                                    placeholder="Ex: 102030"
                                />
                            </td>
                            <td className="px-2 py-2">
                                <input
                                    type="date"
                                    value={product.date}
                                    onChange={(e) => onProductChange(index, 'date', e.target.value)}
                                    className="bg-zinc-900 border border-zinc-700 text-white text-sm rounded-lg focus:ring-orange-500 focus:border-orange-500 block w-full p-2.5 placeholder-gray-500"
                                />
                            </td>
                            <td className="px-2 py-2">
                                <input
                                    type="text"
                                    value={product.reference}
                                    onChange={(e) => onProductChange(index, 'reference', e.target.value)}
                                    className="bg-zinc-900 border border-zinc-700 text-white text-sm rounded-lg focus:ring-orange-500 focus:border-orange-500 block w-full p-2.5 placeholder-gray-500"
                                    placeholder="Ex: FRASLE/2"
                                />
                            </td>
                            <td className="px-2 py-2 min-w-[250px]">
                                <input
                                    type="text"
                                    value={product.description}
                                    onChange={(e) => onProductChange(index, 'description', e.target.value)}
                                    className="bg-zinc-900 border border-zinc-700 text-white text-sm rounded-lg focus:ring-orange-500 focus:border-orange-500 block w-full p-2.5 placeholder-gray-500"
                                    placeholder="Ex: Pastilha de Freio"
                                />
                            </td>
                            <td className="px-2 py-2 w-32">
                                <input
                                    type="number"
                                    value={product.quantity}
                                    onChange={(e) => onProductChange(index, 'quantity', e.target.value)}
                                    className="bg-zinc-900 border border-zinc-700 text-white text-sm rounded-lg focus:ring-orange-500 focus:border-orange-500 block w-full p-2.5 placeholder-gray-500"
                                    placeholder="Ex: 10"
                                />
                            </td>
                            <td className="px-2 py-2 min-w-[150px]">
                                <input
                                    type="text"
                                    value={product.requester}
                                    onChange={(e) => onProductChange(index, 'requester', e.target.value)}
                                    className="bg-zinc-900 border border-zinc-700 text-white text-sm rounded-lg focus:ring-orange-500 focus:border-orange-500 block w-full p-2.5 placeholder-gray-500"
                                    placeholder="Ex: João"
                                />
                            </td>
                            <td className="px-2 py-2 min-w-[150px]">
                                <input
                                    type="text"
                                    value={product.brand}
                                    onChange={(e) => onProductChange(index, 'brand', e.target.value)}
                                    className="bg-zinc-900 border border-zinc-700 text-white text-sm rounded-lg focus:ring-orange-500 focus:border-orange-500 block w-full p-2.5 placeholder-gray-500"
                                    placeholder="Ex: Bosch"
                                />
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default ProductForm;