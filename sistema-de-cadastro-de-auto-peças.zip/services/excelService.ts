import type { Product } from '../types';

// Declaração para que o TypeScript reconheça a variável global XLSX injetada pelo script
declare const XLSX: any;

export const exportToExcel = (products: Product[], fileName: string = 'produtos_autopecas'): void => {
    if (typeof XLSX === 'undefined') {
        console.error('A biblioteca XLSX não foi carregada. Verifique se o script está no HTML.');
        alert('Erro ao exportar: a biblioteca necessária não foi encontrada.');
        return;
    }

    // 1. Definir os cabeçalhos das colunas
    const headers = [
        'Código Interno',
        'Data',
        'Referência',
        'Descrição',
        'Quantidade',
        'Solicitante',
        'Marca',
    ];

    // 2. Mapear os dados dos produtos para o formato de array de arrays, na ordem dos cabeçalhos
    const data = products.map(product => [
        product.internalCode,
        product.date,
        product.reference,
        product.description,
        product.quantity,
        product.requester,
        product.brand
    ]);

    // 3. Criar a planilha (worksheet) a partir dos dados (cabeçalhos + linhas de produtos)
    const ws = XLSX.utils.aoa_to_sheet([headers, ...data]);

    // Opcional: Ajustar a largura das colunas automaticamente
    const colWidths = headers.map((_, i) => {
        const maxLength = Math.max(
            headers[i]?.length || 0,
            ...data.map(row => row[i]?.toString().length || 0)
        );
        return { wch: maxLength + 2 }; // Adiciona um pouco de espaço extra
    });
    ws['!cols'] = colWidths;

    // 4. Criar o livro (workbook) e adicionar a planilha
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Produtos');

    // 5. Gerar o arquivo .xlsx e iniciar o download
    XLSX.writeFile(wb, `${fileName}_${new Date().toISOString().slice(0, 10)}.xlsx`);
};
