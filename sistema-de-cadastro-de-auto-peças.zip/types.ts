export interface Product {
  id?: string; // ID do documento do Firestore
  internalCode: string;
  date: string;
  reference: string;
  description: string;
  quantity: string;
  requester: string;
  brand: string;
}
